import React, { Component } from 'react'

export default class index extends Component {
    render() {
        return (
            <div>
                <h1>别名测试........</h1>
            </div>
        )
    }
}
