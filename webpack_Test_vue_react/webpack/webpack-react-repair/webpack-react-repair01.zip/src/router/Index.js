import React, { Component } from 'react'
import TX from '@/read/index.jsx'
export default class Index extends Component {
    render() {
        return (
            <div>
                <TX></TX>
                <h1>111</h1>
            </div>
        )
    }
}
