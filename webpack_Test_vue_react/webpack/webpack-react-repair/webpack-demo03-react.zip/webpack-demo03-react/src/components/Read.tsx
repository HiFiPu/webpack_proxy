import React, { Component } from 'react'
// import PropTypes from 'prop-types'

export class Read extends Component {
    
    static propTypes = {

    }

    render() {
        return (
            <div>
                <h1>TSX TS WELCOME!</h1>
            </div>
        )
    }
}

export default Read
